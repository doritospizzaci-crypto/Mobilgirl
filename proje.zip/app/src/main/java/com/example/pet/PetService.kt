package com.example.pet

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import java.io.File
import java.util.Calendar
import kotlin.math.abs
import kotlin.math.sin
import kotlin.random.Random

class PetService : Service() {
    private enum class St { FLOOR, WALL_R, WALL_L, CEIL, FALL, DRAG }
    private enum class Act { NONE, SIT, SLEEP, WAVE, JUMP, DANCE, EAT, DIZZY }

    private lateinit var wm: WindowManager
    private lateinit var lp: WindowManager.LayoutParams
    private lateinit var blp: WindowManager.LayoutParams
    private lateinit var prefs: SharedPreferences
    private var pet: PetView? = null
    private var bubble: TextView? = null
    private val handler = Handler(Looper.getMainLooper())

    // ölçüler
    private var d = 1f
    private var size = 0
    private var pad = 0f
    private var sw = 0
    private var sh = 0
    private var botM = 0f
    private var topM = 0f
    private var speedK = 1.6f
    private var minX = 0f
    private var maxX = 0f
    private var topY = 0f
    private var floorY = 0f

    // hareket durumu
    private var st = St.FALL
    private var act = Act.NONE
    private var actT = 0f
    private var actTotal = 1f
    private var dir = 1
    private var x = 0f
    private var y = 0f
    private var vy = 0f
    private var t = 0f
    private var rot = 0f
    private var timer = 150
    private var last = 0L
    private var zCount = 0f

    // dokunma
    private var dragDx = 0f
    private var dragDy = 0f
    private var downX = 0f
    private var downY = 0f
    private var moved = false
    private var lastTapT = 0L
    private var lastRawX = 0f
    private var lastSign = 0
    private var shakeCnt = 0
    private var shakeT0 = 0L
    private var dizzyPending = false

    // oyun durumu
    private var charging = false
    private var happy = 60f
    private var full = 70f
    private var xp = 0
    private var lastStat = 0L
    private var lastHungry = 0L
    private var lastRemind = 0L
    private var bubbleUntil = 0L
    private var remindMsg = ""
    private var remindMs = 0L
    private var rcvOn = false

    private val rcv = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            when (i?.action) {
                Intent.ACTION_POWER_CONNECTED -> {
                    charging = true
                    say("Şarj oluyorum 🔋", 3000L)
                }
                Intent.ACTION_POWER_DISCONNECTED -> {
                    charging = false
                    if (act == Act.SLEEP) act = Act.NONE
                    say("Şarj bitti ⚡", 2500L)
                }
                Intent.ACTION_BATTERY_LOW -> say("Pil azaldı 😢 şarja tak!", 5000L)
                else -> {}
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val a = intent?.action
        if (a == "STOP") {
            stopSelf()
            return START_NOT_STICKY
        }
        startFg()
        if (pet == null) createPet()
        if (a == "FEED") feed()
        return START_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("pet", "Maskot", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val feedPi = PendingIntent.getService(this, 1, Intent(this, PetService::class.java).setAction("FEED"), PendingIntent.FLAG_IMMUTABLE)
        val stopPi = PendingIntent.getService(this, 2, Intent(this, PetService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "pet")
            .setContentTitle("Maskot ekranda")
            .setContentText("Mama vermek için bildirimi aşağı çek")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.ic_menu_add), "Mama ver", feedPi).build())
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Kapat", stopPi).build())
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    private fun createPet() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        prefs = getSharedPreferences("pet", MODE_PRIVATE)
        d = resources.displayMetrics.density
        size = ((60 + prefs.getInt("size_p", 50)) * d).toInt()
        pad = size * 0.12f
        speedK = (5 + prefs.getInt("speed_p", 11)) / 10f
        botM = 40 * d
        topM = 28 * d
        happy = prefs.getFloat("happy", 60f)
        full = prefs.getFloat("full", 70f)
        xp = prefs.getInt("xp", 0)
        remindMsg = prefs.getString("msg", "") ?: ""
        remindMs = (1 + prefs.getInt("min_p", 9)) * 60000L

        // karakter
        val iv = PetView(this)
        val custom = File(filesDir, "custom.png")
        val bmp = if (custom.exists()) BitmapFactory.decodeFile(custom.path) else null
        if (bmp != null) iv.whole = bmp else iv.loadDefault()
        iv.padPx = pad

        // konuşma balonu
        val tv = TextView(this)
        tv.textSize = 14f
        tv.setTextColor(Color.BLACK)
        val bg = GradientDrawable()
        bg.setColor(Color.WHITE)
        bg.cornerRadius = 14 * d
        bg.setStroke((1.5f * d).toInt(), Color.parseColor("#0B2A3A"))
        tv.background = bg
        tv.setPadding((10 * d).toInt(), (6 * d).toInt(), (10 * d).toInt(), (6 * d).toInt())
        tv.maxWidth = (220 * d).toInt()
        tv.visibility = View.GONE

        val flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        lp = WindowManager.LayoutParams(
            size, size, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        blp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        )
        blp.gravity = Gravity.TOP or Gravity.START

        iv.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    if (!moved && (abs(e.rawX - downX) > 10 * d || abs(e.rawY - downY) > 10 * d)) {
                        moved = true
                        st = St.DRAG
                        act = Act.NONE
                        dragDx = e.rawX - x
                        dragDy = e.rawY - y
                        lastRawX = e.rawX
                        lastSign = 0
                        shakeCnt = 0
                        shakeT0 = SystemClock.uptimeMillis()
                    }
                    if (moved) {
                        x = e.rawX - dragDx
                        y = e.rawY - dragDy
                        trackShake(e.rawX)
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (moved) {
                        release()
                    } else if (e.actionMasked == MotionEvent.ACTION_UP) {
                        onTap()
                    }
                    moved = false
                    true
                }
                else -> false
            }
        }

        // pil durumu
        val f = IntentFilter()
        f.addAction(Intent.ACTION_POWER_CONNECTED)
        f.addAction(Intent.ACTION_POWER_DISCONNECTED)
        f.addAction(Intent.ACTION_BATTERY_LOW)
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(rcv, f, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(rcv, f)
        }
        rcvOn = true
        val sticky = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        charging = (sticky?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0) != 0

        x = (resources.displayMetrics.widthPixels - size) / 2f
        y = 0f
        st = St.FALL
        val now = SystemClock.uptimeMillis()
        last = now
        lastStat = now
        lastHungry = now
        lastRemind = now
        try {
            wm.addView(tv, blp)
            bubble = tv
            wm.addView(iv, lp)
            pet = iv
            val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
            val hi = if (h < 6) "İyi geceler 🌙" else if (h < 12) "Günaydın ☀️" else if (h < 18) "Merhaba 👋" else "İyi akşamlar 🌆"
            say(hi, 3500L)
            tick()
        } catch (e: Exception) {
            stopSelf()
        }
    }

    private fun say(text: String, ms: Long = 2500L) {
        val b = bubble ?: return
        b.text = text
        b.visibility = View.VISIBLE
        bubbleUntil = SystemClock.uptimeMillis() + ms
    }

    private fun save() {
        if (!::prefs.isInitialized) return
        prefs.edit().putFloat("happy", happy).putFloat("full", full).putInt("xp", xp).apply()
    }

    private fun addXp(n: Int) {
        val old = 1 + xp / 20
        xp += n
        if (1 + xp / 20 > old) say("Seviye ${1 + xp / 20}! 🎉", 3000L)
        save()
    }

    private fun startAct(a: Act, frames: Float) {
        act = a
        actT = frames
        actTotal = frames
    }

    private fun feed() {
        full = (full + 30f).coerceAtMost(100f)
        happy = (happy + 8f).coerceAtMost(100f)
        addXp(2)
        say("Nam nam 😋", 2500L)
        if (st == St.FLOOR) startAct(Act.EAT, 100f)
        save()
    }

    private fun onTap() {
        val now = SystemClock.uptimeMillis()
        val dbl = now - lastTapT < 450L
        lastTapT = now
        if (act == Act.SLEEP && charging) {
            say("Şşş, uyuyorum 😴", 2000L)
            return
        }
        happy = (happy + 4f).coerceAtMost(100f)
        addXp(1)
        if (dbl) {
            say("🎵 Dans zamanı! 🎵", 3000L)
            if (st == St.FLOOR) startAct(Act.DANCE, 150f)
        } else {
            val lines = arrayOf("💕", "Hihi 😊", "Gıdıklanıyorum!", "Beni sev 💗", "Merhaba! 👋", "❤️")
            say(lines.random(), 2000L)
            if (st == St.FLOOR) startAct(if (Random.nextBoolean()) Act.JUMP else Act.WAVE, 70f)
        }
    }

    private fun trackShake(rawX: Float) {
        val dx = rawX - lastRawX
        if (abs(dx) > 4 * d) {
            val s = if (dx > 0) 1 else -1
            if (lastSign != 0 && s != lastSign) {
                val n = SystemClock.uptimeMillis()
                if (n - shakeT0 > 1200L) {
                    shakeCnt = 0
                    shakeT0 = n
                }
                shakeCnt++
                if (shakeCnt >= 5 && !dizzyPending) {
                    dizzyPending = true
                    say("Başım döndü 😵", 2500L)
                }
            }
            lastSign = s
            lastRawX = rawX
        }
    }

    // Parmağı bırakınca: kenara yakınsa tutun, değilse düş
    private fun release() {
        val edge = size * 0.3f
        if (x <= minX + edge) {
            x = minX
            st = St.WALL_L
            dir = -1
        } else if (x >= maxX - edge) {
            x = maxX
            st = St.WALL_R
            dir = -1
        } else if (y <= topY + edge) {
            y = topY
            st = St.CEIL
            dir = if (Random.nextBoolean()) 1 else -1
        } else {
            st = St.FALL
            vy = 0f
        }
        timer = rnd()
    }

    private fun rnd() = Random.nextInt(150, 450)

    private fun pickAction() {
        when (Random.nextInt(10)) {
            0, 1 -> dir = -dir
            2 -> startAct(Act.SIT, Random.nextInt(200, 400).toFloat())
            3 -> startAct(Act.SLEEP, Random.nextInt(400, 800).toFloat())
            4 -> {
                startAct(Act.WAVE, 90f)
                say("👋", 1500L)
            }
            5 -> startAct(Act.JUMP, 55f)
            else -> {}
        }
    }

    private fun tick() {
        val v = pet ?: return
        val now = SystemClock.uptimeMillis()
        val dt = ((now - last) / 16f).coerceIn(0.2f, 3f)
        last = now

        val m = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(m)
        sw = m.widthPixels
        sh = m.heightPixels
        minX = -pad
        maxX = sw - size + pad
        topY = topM - pad
        floorY = sh - size - botM + pad

        val spd = speedK * d * dt
        t += 0.28f * dt
        var target = 0f
        var walking = true
        if (st != St.FLOOR && act != Act.NONE) act = Act.NONE

        when (st) {
            St.FLOOR -> {
                if (act == Act.NONE) {
                    y = floorY
                    x += dir * spd
                    if (x >= maxX) {
                        x = maxX
                        st = St.WALL_R
                        dir = -1
                        timer = rnd()
                    } else if (x <= minX) {
                        x = minX
                        st = St.WALL_L
                        dir = -1
                        timer = rnd()
                    } else if (charging) {
                        startAct(Act.SLEEP, 1e9f)
                    } else {
                        timer--
                        if (timer <= 0) {
                            pickAction()
                            timer = rnd()
                        }
                    }
                } else {
                    walking = false
                    actT -= dt
                    if (act == Act.JUMP) {
                        val prog = (1f - actT / actTotal).coerceIn(0f, 1f)
                        y = floorY - sin(Math.PI * prog).toFloat() * size * 0.6f
                        x += dir * spd * 0.8f
                    } else {
                        y = floorY
                    }
                    if (act == Act.SLEEP) {
                        zCount -= dt
                        if (zCount <= 0f) {
                            say("Zzz… 💤", 1800L)
                            zCount = 180f
                        }
                    }
                    if (actT <= 0f) {
                        act = Act.NONE
                        y = floorY
                        timer = rnd()
                    }
                }
            }
            St.WALL_R, St.WALL_L -> {
                val right = st == St.WALL_R
                x = if (right) maxX else minX
                y += dir * spd
                target = if (right) -90f else 90f
                if (y <= topY) {
                    y = topY
                    st = St.CEIL
                    dir = if (right) -1 else 1
                    timer = rnd()
                } else if (y >= floorY) {
                    y = floorY
                    st = St.FLOOR
                    dir = if (right) -1 else 1
                    timer = rnd()
                } else {
                    timer--
                    if (timer <= 0) {
                        when (Random.nextInt(3)) {
                            0 -> {
                                st = St.FALL
                                vy = 0f
                            }
                            1 -> dir = -dir
                            else -> {}
                        }
                        timer = rnd()
                    }
                }
            }
            St.CEIL -> {
                y = topY
                target = 180f
                x += dir * spd
                if (x >= maxX) {
                    x = maxX
                    st = St.WALL_R
                    dir = 1
                    timer = rnd()
                } else if (x <= minX) {
                    x = minX
                    st = St.WALL_L
                    dir = 1
                    timer = rnd()
                } else {
                    timer--
                    if (timer <= 0) {
                        if (Random.nextBoolean()) {
                            st = St.FALL
                            vy = 0f
                        } else {
                            dir = -dir
                        }
                        timer = rnd()
                    }
                }
            }
            St.FALL -> {
                walking = false
                vy += 0.5f * d * dt
                y += vy * dt
                if (y >= floorY) {
                    val hard = vy > 15f * d
                    y = floorY
                    st = St.FLOOR
                    dir = if (x > sw / 2f) -1 else 1
                    timer = rnd()
                    vy = 0f
                    if (dizzyPending) {
                        dizzyPending = false
                        startAct(Act.DIZZY, 160f)
                    } else if (hard) {
                        startAct(Act.SIT, 25f)
                    }
                }
            }
            St.DRAG -> {
                walking = false
            }
        }

        x = x.coerceIn(minX, maxX)
        y = y.coerceIn(topY, floorY)

        // oyun istatistikleri
        if (now - lastStat > 30000L) {
            lastStat = now
            full = (full - 1f).coerceAtLeast(0f)
            happy = (happy - (if (full < 10f) 1.5f else 0.5f)).coerceAtLeast(0f)
            save()
        }
        if (full < 25f && now - lastHungry > 120000L) {
            lastHungry = now
            say("Acıktım 🍙 Bildirimden mama ver!", 4000L)
        }
        if (remindMs > 0L && remindMsg.isNotBlank() && now - lastRemind > remindMs) {
            lastRemind = now
            say(remindMsg, 6000L)
        }

        // görünüm
        var sx = if (st == St.FLOOR && dir < 0) -1f else 1f
        var sy = 1f
        var wob = if (walking) sin(t) * 6f else sin(t * 0.6f) * 12f
        when (act) {
            Act.NONE -> {}
            Act.SIT -> {
                sy = 0.88f + 0.015f * sin(t)
                wob = 0f
            }
            Act.SLEEP -> {
                sy = 0.85f + 0.02f * sin(t * 0.5f)
                target = 12f
                wob = 0f
            }
            Act.WAVE -> wob = sin(t * 3f) * 14f
            Act.JUMP -> wob = 0f
            Act.DANCE -> {
                wob = sin(t * 2.5f) * 20f
                sx = if (sin(t * 2.5f) > 0f) 1f else -1f
                sy = 1f + 0.05f * sin(t * 5f)
            }
            Act.EAT -> {
                sy = 0.93f + 0.07f * sin(t * 4f)
                wob = 0f
            }
            Act.DIZZY -> wob = sin(t * 2f) * 25f
        }
        if (walking) sy *= 1f + 0.03f * sin(t * 2f)

        // kol ve bacak açıları (pozitif = dışarı)
        var aL = 0f
        var aR = 0f
        var lL = 0f
        var lR = 0f
        if (st == St.FLOOR && act == Act.NONE) {
            val s = sin(t)
            aL = 18f * s
            aR = -18f * s
            lL = 20f * s
            lR = -20f * s
        } else if (st == St.WALL_R || st == St.WALL_L || st == St.CEIL) {
            val s = sin(t * 1.3f)
            aL = 40f + 30f * s
            aR = 40f - 30f * s
            lL = 8f + 22f * s
            lR = 8f - 22f * s
        } else if (st == St.FALL || st == St.DRAG) {
            aL = 40f + 25f * sin(t * 3f)
            aR = 40f + 25f * sin(t * 3f + 1.7f)
            lL = 15f + 15f * sin(t * 2.6f)
            lR = 15f + 15f * sin(t * 2.6f + 2f)
        } else {
            when (act) {
                Act.NONE -> {}
                Act.SIT -> {
                    aL = 8f
                    aR = 8f
                    lL = 35f
                    lR = 35f
                }
                Act.SLEEP -> {
                    aL = 5f
                    aR = 5f
                    lL = 8f
                    lR = 8f
                }
                Act.WAVE -> {
                    aL = 6f
                    aR = 140f + 25f * sin(t * 3.5f)
                }
                Act.JUMP -> {
                    aL = 120f
                    aR = 120f
                    lL = 18f
                    lR = 18f
                }
                Act.DANCE -> {
                    val s = sin(t * 2.5f)
                    aL = 70f + 50f * s
                    aR = 70f - 50f * s
                    lL = 25f * s
                    lR = -25f * s
                }
                Act.EAT -> {
                    aL = -50f + 8f * sin(t * 4f)
                    aR = -50f + 8f * sin(t * 4f)
                }
                Act.DIZZY -> {
                    aL = 30f * sin(t * 2f)
                    aR = -30f * sin(t * 2f)
                    lL = 12f * sin(t * 2f)
                    lR = -12f * sin(t * 2f)
                }
            }
        }
        v.armL = aL
        v.armR = aR
        v.legL = lL
        v.legR = lR
        v.dizzy = act == Act.DIZZY || dizzyPending
        v.spin = t * 35f
        v.invalidate()

        val diff = ((target - rot) % 360f + 540f) % 360f - 180f
        rot += diff * 0.2f * dt
        v.rotation = rot + wob
        v.scaleX = sx
        v.scaleY = sy
        v.translationY = if (st == St.FLOOR) (1f - sy).coerceAtLeast(0f) * (size - 2 * pad) / 2f else 0f

        lp.x = x.toInt()
        lp.y = y.toInt()
        try {
            wm.updateViewLayout(v, lp)
        } catch (e: Exception) {
        }

        // konuşma balonu
        val b = bubble
        if (b != null && b.visibility == View.VISIBLE) {
            if (now > bubbleUntil) {
                b.visibility = View.GONE
            } else {
                b.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED)
                val bw = b.measuredWidth
                val bh = b.measuredHeight
                var bx = x + size / 2f - bw / 2f
                bx = bx.coerceIn(0f, (sw - bw).toFloat().coerceAtLeast(0f))
                var by = y + pad - bh - 6 * d
                if (by < 0f) by = y + size - pad + 6 * d
                blp.x = bx.toInt()
                blp.y = by.toInt()
                try {
                    wm.updateViewLayout(b, blp)
                } catch (e: Exception) {
                }
            }
        }
        handler.postDelayed({ tick() }, 16)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        if (rcvOn) {
            try {
                unregisterReceiver(rcv)
            } catch (e: Exception) {
            }
            rcvOn = false
        }
        pet?.let {
            try {
                wm.removeView(it)
            } catch (e: Exception) {
            }
        }
        bubble?.let {
            try {
                wm.removeView(it)
            } catch (e: Exception) {
            }
        }
        pet = null
        bubble = null
        save()
        super.onDestroy()
    }
}
