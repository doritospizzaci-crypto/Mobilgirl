package com.example.pet

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.ImageView
import kotlin.math.sin
import kotlin.random.Random

class PetService : Service() {
    private enum class St { FLOOR, WALL_R, WALL_L, CEIL, FALL, DRAG }

    private lateinit var wm: WindowManager
    private lateinit var lp: WindowManager.LayoutParams
    private var pet: ImageView? = null
    private val handler = Handler(Looper.getMainLooper())

    private var d = 1f
    private var size = 0
    private var sw = 0
    private var sh = 0
    private var botM = 0f   // alt boşluk (navigasyon çubuğu için)
    private var topM = 0f   // üst boşluk (durum çubuğu için)
    private var st = St.FALL
    private var dir = 1
    private var x = 0f
    private var y = 0f
    private var vy = 0f
    private var t = 0f
    private var rot = 0f
    private var timer = 150
    private var last = 0L
    private var dragDx = 0f
    private var dragDy = 0f

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") {
            stopSelf()
            return START_NOT_STICKY
        }
        startFg()
        if (pet == null) createPet()
        return START_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("pet", "Maskot", NotificationManager.IMPORTANCE_LOW))
        val stopPi = PendingIntent.getService(
            this, 0, Intent(this, PetService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, "pet")
            .setContentTitle("Maskot ekranda")
            .setContentText("Kapatmak için dokun")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(stopPi)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    private fun createPet() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        d = resources.displayMetrics.density
        size = (110 * d).toInt()
        botM = 40 * d
        topM = 28 * d

        val iv = ImageView(this)
        iv.setImageResource(R.drawable.pet)
        iv.scaleType = ImageView.ScaleType.FIT_CENTER

        val flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        lp = WindowManager.LayoutParams(
            size, size, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START

        iv.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    st = St.DRAG
                    dragDx = e.rawX - x
                    dragDy = e.rawY - y
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    x = e.rawX - dragDx
                    y = e.rawY - dragDy
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    release()
                    true
                }
                else -> false
            }
        }

        x = (resources.displayMetrics.widthPixels - size) / 2f
        y = 0f
        st = St.FALL
        last = SystemClock.uptimeMillis()
        try {
            wm.addView(iv, lp)
            pet = iv
            tick()
        } catch (e: Exception) {
            stopSelf()
        }
    }

    // Parmağı bırakınca: kenara yakınsa tutun, değilse düş
    private fun release() {
        val edge = size * 0.3f
        val rightX = (sw - size).toFloat()
        if (x <= edge) {
            x = 0f
            st = St.WALL_L
            dir = -1
        } else if (x >= rightX - edge) {
            x = rightX
            st = St.WALL_R
            dir = -1
        } else if (y <= topM + edge) {
            y = topM
            st = St.CEIL
            dir = if (Random.nextBoolean()) 1 else -1
        } else {
            st = St.FALL
            vy = 0f
        }
        timer = rnd()
    }

    private fun rnd() = Random.nextInt(150, 450)

    private fun tick() {
        val v = pet ?: return
        val now = SystemClock.uptimeMillis()
        val dt = ((now - last) / 16f).coerceIn(0.2f, 3f)
        last = now

        val m = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(m)
        sw = m.widthPixels
        sh = m.heightPixels

        val floorY = sh - size - botM
        val rightX = (sw - size).toFloat()
        val spd = 1.6f * d * dt   // yürüme hızı (artırırsan hızlanır)
        t += 0.28f * dt
        var target = 0f
        var walking = true

        when (st) {
            St.FLOOR -> {
                y = floorY
                x += dir * spd
                if (x >= rightX) {
                    x = rightX
                    st = St.WALL_R
                    dir = -1
                    timer = rnd()
                } else if (x <= 0f) {
                    x = 0f
                    st = St.WALL_L
                    dir = -1
                    timer = rnd()
                } else {
                    timer--
                    if (timer <= 0) {
                        if (Random.nextInt(3) == 0) dir = -dir
                        timer = rnd()
                    }
                }
            }
            St.WALL_R, St.WALL_L -> {
                val right = st == St.WALL_R
                x = if (right) rightX else 0f
                y += dir * spd
                target = if (right) -90f else 90f
                if (y <= topM) {
                    y = topM
                    st = St.CEIL
                    dir = if (right) -1 else 1
                    timer = rnd()
                } else if (y >= floorY) {
                    y = floorY
                    st = St.FLOOR
                    dir = if (right) -1 else 1
                    timer = rnd()
                } else {
                    timer--
                    if (timer <= 0) {
                        when (Random.nextInt(3)) {
                            0 -> {
                                st = St.FALL
                                vy = 0f
                            }
                            1 -> dir = -dir
                            else -> {}
                        }
                        timer = rnd()
                    }
                }
            }
            St.CEIL -> {
                y = topM
                target = 180f
                x += dir * spd
                if (x >= rightX) {
                    x = rightX
                    st = St.WALL_R
                    dir = 1
                    timer = rnd()
                } else if (x <= 0f) {
                    x = 0f
                    st = St.WALL_L
                    dir = 1
                    timer = rnd()
                } else {
                    timer--
                    if (timer <= 0) {
                        if (Random.nextBoolean()) {
                            st = St.FALL
                            vy = 0f
                        } else {
                            dir = -dir
                        }
                        timer = rnd()
                    }
                }
            }
            St.FALL -> {
                walking = false
                vy += 0.5f * d * dt
                y += vy * dt
                if (y >= floorY) {
                    y = floorY
                    st = St.FLOOR
                    dir = if (x > sw / 2f) -1 else 1
                    timer = rnd()
                }
            }
            St.DRAG -> {
                walking = false
            }
        }

        x = x.coerceIn(0f, rightX)
        y = y.coerceIn(0f, floorY)

        val diff = ((target - rot) % 360f + 540f) % 360f - 180f
        rot += diff * 0.2f * dt

        val wob = if (walking) sin(t) * 6f else sin(t * 0.6f) * 12f
        v.rotation = rot + wob
        v.scaleX = if (st == St.FLOOR && dir < 0) -1f else 1f
        v.scaleY = if (walking) 1f + 0.03f * sin(t * 2f) else 1f

        lp.x = x.toInt()
        lp.y = y.toInt()
        try {
            wm.updateViewLayout(v, lp)
        } catch (e: Exception) {
        }
        handler.postDelayed({ tick() }, 16)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        pet?.let {
            try {
                wm.removeView(it)
            } catch (e: Exception) {
            }
        }
        pet = null
        super.onDestroy()
    }
}
