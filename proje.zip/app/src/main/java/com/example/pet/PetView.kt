package com.example.pet

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

// Karakteri parça parça çizer: bacaklar (arkada), gövde, kollar (önde).
// Açılar derece cinsindendir; pozitif değer = dışarı doğru açılma.
class PetView(ctx: Context) : View(ctx) {
    private class Part(
        val bmp: Bitmap,
        val l: Float, val t: Float, val r: Float, val b: Float,
        val px: Float, val py: Float
    )

    var whole: Bitmap? = null   // özel resim (parçasız)
    var padPx = 0f
    var armL = 0f
    var armR = 0f
    var legL = 0f
    var legR = 0f
    var dizzy = false
    var spin = 0f

    private var body: Bitmap? = null
    private var pArmL: Part? = null
    private var pArmR: Part? = null
    private var pLegL: Part? = null
    private var pLegR: Part? = null

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val eyeFill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val spiralPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()

    init {
        eyeFill.color = Color.parseColor("#0B1030")
        eyeFill.style = Paint.Style.FILL
        spiralPaint.color = Color.WHITE
        spiralPaint.style = Paint.Style.STROKE
        spiralPaint.strokeWidth = 8f
        spiralPaint.strokeCap = Paint.Cap.ROUND
        spiralPaint.strokeJoin = Paint.Join.ROUND
    }

    fun loadDefault() {
        val r = resources
        body = BitmapFactory.decodeResource(r, R.drawable.pet_body)
        pArmL = Part(BitmapFactory.decodeResource(r, R.drawable.pet_arm_l), 215f, 568f, 349f, 776f, 330f, 602f)
        pArmR = Part(BitmapFactory.decodeResource(r, R.drawable.pet_arm_r), 628f, 588f, 771f, 778f, 692f, 608f)
        pLegL = Part(BitmapFactory.decodeResource(r, R.drawable.pet_leg_l), 338f, 825f, 472f, 935f, 405f, 838f)
        pLegR = Part(BitmapFactory.decodeResource(r, R.drawable.pet_leg_r), 492f, 825f, 642f, 940f, 567f, 842f)
    }

    private fun drawPart(c: Canvas, p: Part?, deg: Float) {
        if (p == null) return
        c.save()
        c.rotate(deg, p.px, p.py)
        c.drawBitmap(p.bmp, null, RectF(p.l, p.t, p.r, p.b), paint)
        c.restore()
    }

    private fun drawEye(c: Canvas, cx: Float, cy: Float, dir: Float) {
        c.drawCircle(cx, cy, 62f, eyeFill)
        path.reset()
        val steps = 70
        val turns = 2.6
        val off = Math.toRadians((spin * dir).toDouble())
        for (i in 0..steps) {
            val f = i / steps.toDouble()
            val ang = f * turns * 2.0 * Math.PI + off
            val rad = 5.0 + 50.0 * f
            val px = (cx + rad * cos(ang)).toFloat()
            val py = (cy + rad * sin(ang)).toFloat()
            if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
        }
        c.drawPath(path, spiralPaint)
    }

    override fun onDraw(c: Canvas) {
        val area = width - 2 * padPx
        c.save()
        c.translate(padPx, padPx)
        val k = area / 1024f
        c.scale(k, k)
        val b = body
        val w = whole
        if (b == null) {
            if (w != null) {
                val s = min(1024f / w.width, 1024f / w.height)
                val dw = w.width * s
                val dh = w.height * s
                c.drawBitmap(w, null, RectF((1024f - dw) / 2f, (1024f - dh) / 2f, (1024f + dw) / 2f, (1024f + dh) / 2f), paint)
            }
        } else {
            drawPart(c, pLegL, legL)
            drawPart(c, pLegR, -legR)
            c.drawBitmap(b, null, RectF(0f, 0f, 1024f, 1024f), paint)
            drawPart(c, pArmL, armL)
            drawPart(c, pArmR, -armR)
            if (dizzy) {
                drawEye(c, 313f, 398f, 1f)
                drawEye(c, 572f, 432f, 1f)
            }
        }
        c.restore()
    }
}
