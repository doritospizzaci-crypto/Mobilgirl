package com.example.pet

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (24 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER
        root.setPadding(pad, pad, pad, pad)

        val title = TextView(this)
        title.text = "Ekran Maskotu"
        title.textSize = 26f
        title.gravity = Gravity.CENTER

        val start = Button(this)
        start.text = "Başlat"
        val stop = Button(this)
        stop.text = "Durdur"

        start.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Önce 'Diğer uygulamaların üzerinde göster' iznini aç, sonra tekrar Başlat'a bas", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else {
                if (Build.VERSION.SDK_INT >= 33) {
                    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
                }
                startForegroundService(Intent(this, PetService::class.java))
            }
        }
        stop.setOnClickListener { stopService(Intent(this, PetService::class.java)) }

        root.addView(title)
        root.addView(start)
        root.addView(stop)
        setContentView(root)
    }
}
