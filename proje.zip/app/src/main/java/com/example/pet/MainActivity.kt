package com.example.pet

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream

class MainActivity : Activity() {
    private lateinit var prefs: SharedPreferences
    private lateinit var stats: TextView
    private lateinit var msg: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("pet", MODE_PRIVATE)
        val d = resources.displayMetrics.density
        val pad = (20 * d).toInt()
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(pad, pad, pad, pad)

        val title = TextView(this)
        title.text = "Ekran Maskotu"
        title.textSize = 26f
        title.gravity = Gravity.CENTER
        stats = TextView(this)
        stats.textSize = 15f
        stats.gravity = Gravity.CENTER
        root.addView(title)
        root.addView(stats)

        val start = Button(this)
        start.text = "Başlat (ayarları uygular)"
        val stop = Button(this)
        stop.text = "Durdur"
        val feed = Button(this)
        feed.text = "Mama ver 🍙"
        root.addView(start)
        root.addView(feed)
        root.addView(stop)

        addSeek(root, "Boyut", 160, "size_p", 50)
        addSeek(root, "Yürüme hızı", 35, "speed_p", 11)
        addSeek(root, "Hatırlatma aralığı (1-60 dk)", 59, "min_p", 9)

        msg = EditText(this)
        msg.hint = "Hatırlatma mesajı (örn. Su iç!)"
        msg.setText(prefs.getString("msg", "") ?: "")
        root.addView(msg)

        val pick = Button(this)
        pick.text = "Kendi resmini seç"
        val reset = Button(this)
        reset.text = "Varsayılan resme dön"
        root.addView(pick)
        root.addView(reset)

        start.setOnClickListener {
            prefs.edit().putString("msg", msg.text.toString()).apply()
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Önce 'Diğer uygulamaların üzerinde göster' iznini aç, sonra tekrar Başlat'a bas", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else {
                if (Build.VERSION.SDK_INT >= 33) {
                    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
                }
                stopService(Intent(this, PetService::class.java))
                startForegroundService(Intent(this, PetService::class.java))
            }
        }
        stop.setOnClickListener { stopService(Intent(this, PetService::class.java)) }
        feed.setOnClickListener {
            if (Settings.canDrawOverlays(this)) {
                startForegroundService(Intent(this, PetService::class.java).setAction("FEED"))
            } else {
                Toast.makeText(this, "Önce Başlat'a bas", Toast.LENGTH_SHORT).show()
            }
        }
        pick.setOnClickListener {
            val i = Intent(Intent.ACTION_GET_CONTENT)
            i.type = "image/*"
            startActivityForResult(i, 2)
        }
        reset.setOnClickListener {
            File(filesDir, "custom.png").delete()
            Toast.makeText(this, "Varsayılan resim seçildi, Başlat'a bas", Toast.LENGTH_SHORT).show()
        }

        val sv = ScrollView(this)
        sv.addView(root)
        setContentView(sv)
    }

    private fun addSeek(root: LinearLayout, label: String, max: Int, key: String, def: Int) {
        val tv = TextView(this)
        tv.text = label
        tv.setPadding(0, (16 * resources.displayMetrics.density).toInt(), 0, 0)
        val sb = SeekBar(this)
        sb.max = max
        sb.progress = prefs.getInt(key, def)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                prefs.edit().putInt(key, p).apply()
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        root.addView(tv)
        root.addView(sb)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (requestCode == 2 && resultCode == RESULT_OK && uri != null) {
            try {
                val bmp = contentResolver.openInputStream(uri).use { BitmapFactory.decodeStream(it) }
                if (bmp != null) {
                    val k = 384f / maxOf(bmp.width, bmp.height)
                    val sc = if (k < 1f) {
                        Bitmap.createScaledBitmap(bmp, (bmp.width * k).toInt(), (bmp.height * k).toInt(), true)
                    } else {
                        bmp
                    }
                    FileOutputStream(File(filesDir, "custom.png")).use { sc.compress(Bitmap.CompressFormat.PNG, 100, it) }
                    Toast.makeText(this, "Resim ayarlandı, Başlat'a bas", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this, "Resim yüklenemedi", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        val xp = prefs.getInt("xp", 0)
        stats.text = "Seviye ${1 + xp / 20}  •  Mutluluk ${prefs.getFloat("happy", 60f).toInt()}  •  Tokluk ${prefs.getFloat("full", 70f).toInt()}"
    }

    override fun onPause() {
        super.onPause()
        prefs.edit().putString("msg", msg.text.toString()).apply()
    }
}
